package Store;

import java.util.ArrayList;

public class Global {
	static public double subtotal = 0;
	static public Customer customer;
	static public ArrayList<Purchase> cart;
}
